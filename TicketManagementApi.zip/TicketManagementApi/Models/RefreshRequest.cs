namespace TicketManagementApi.Models;

public class RefreshRequest
{
    public string RefreshToken { get; set; } = string.Empty;
}
